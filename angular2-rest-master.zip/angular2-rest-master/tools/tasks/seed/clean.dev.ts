import {DEV_DEST} from '../../config';
import {clean} from '../../utils';

export = clean(DEV_DEST)
