import {serveCoverage} from '../../utils';

export = serveCoverage
