import {watch} from '../../utils';

export = watch('build.dev')
